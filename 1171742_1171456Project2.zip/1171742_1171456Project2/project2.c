#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/wait.h>
#include <time.h>
#include <signal.h>
#include <string.h>
#include <limits.h>
#include <sys/msg.h>
union semun
{
    int              val;
    struct semid_ds *buf;
    ushort          *array;
};

int main(void)
{

    static struct sembuf acquire = {0, -1, SEM_UNDO},release = {0, 1, SEM_UNDO};
    int semid, sem_value, i;
    pid_t pid, pids[7], pidsP[7];
    struct semid_ds sem_buf;
    static ushort   sem_array[8] = {0,1,2,3,4,5,0,0};
    union semun     arg;
    enum {p0,p1,p2,p3,p4,p5,allP,round};
    int a=0,b=1,c=2,d=3,e=4,f=5,g=6,h=7,ii=8;
//   A 0
//   B 1
//   C 2
//   D 3
//   E 4
//   F 5
//   G 6
//   H 7
//   I 8
    pidsP[0]=getpid();

    printf("parent id = %d \n===== Round #0 =====\n", pidsP[0]);


    key_t ipc_key=ftok(".", 'S');
    pids[0]=ipc_key;
    semid = semget(ipc_key, 8, IPC_CREAT | 0666);
    pids[1] = semget(ipc_key, 8,0);
    pids[2] = semget(ipc_key, 8,0);
    pids[3] = semget(ipc_key, 8,0);
    pids[4] = semget(ipc_key, 8,0);
    pids[5] = semget(ipc_key, 8,0);
    pids[6] = semget(ipc_key, 8,0);


    arg.array = sem_array;
    semctl(semid, 0, SETALL, arg) ;


    char l[9]= {'A','B','C','D','E','F','G','H','I'};
    for ( i = 0; i < 6; i++ )
    {
        sem_value = semctl(semid, i, GETVAL, 0);
        printf("Process # %d at location : %c \n",i, l[sem_value]);

    }

    while(semctl(semid,7,GETVAL,0)<10)
    {

        if(semctl(semid, 6, GETVAL, 0)==6)
        {
            release.sem_num = round;
            semop(semid, &release, 1);
            //printf("======= Round #%d =======\n",semctl(semid,7,GETVAL,0));
            arg.array = sem_array;
            arg.val=0;
            semctl(semid, 0, SETVAL,arg) ;
            arg.val=1;
            semctl(semid, 1, SETVAL,arg) ;
            arg.val=2;
            semctl(semid, 2, SETVAL,arg) ;
            arg.val=3;
            semctl(semid, 3, SETVAL,arg) ;
            arg.val=4;
            semctl(semid, 4, SETVAL,arg) ;
            arg.val=5;
            semctl(semid, 5, SETVAL,arg) ;
            arg.val=0;
            semctl(semid, 6, SETVAL,arg) ;
        }



        for ( i = 1; i < 7; i++ )
        {
            int time0,time01,time02,time3,time4,time5;
            if(semctl(semid, 6, GETVAL, 0)<6)
            {

                pid = fork();
                if ( pid == 0 )
                {
                    if(i==1)
                    {
                        ////printf("================= P0 ===================\n");
                        srand(getpid());
                        time0=(rand()%5)+1;
                        if((pidsP[0]+1)==getpid())  // to prevent child forking
                        {
                            if(semctl(pids[1],0, GETVAL, 0)==a)  // P0 : A to G
                            {
                                printf("p0 start moving to location G (in %d seconds)\n",time0);


                                sleep(time0);
                                while(semctl(pids[1],0, GETVAL, 0)!=g)
                                {
                                    release.sem_num = p0;
                                    semop(pids[1], &release, 1);
                                }
                                printf("p0 got to location G\n");
                                sem_value = semctl(semid, 0, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",0, l[sem_value]);

                            }
                            //printf("*p0 -> %d\n",semctl(semid, 0, GETVAL, 0));
                            //sleep(2);
                            //printf("**p0 -> %d\n",semctl(semid, 0, GETVAL, 0));
                            // printf("p0 == %d %d %d \n",semctl(pids[1],0, GETVAL, 0),semctl(pids[1],1, GETVAL, 0),semctl(pids[1],2, GETVAL, 0));
                            while((semctl(pids[1],0, GETVAL, 0)<g) ||(semctl(pids[1],1, GETVAL, 0)<g)||(semctl(pids[1],2, GETVAL, 0)<g));
                            //printf("p0 aaaaa H \n");
                            if ((semctl(pids[1],0, GETVAL, 0)>=g) &&(semctl(pids[1],1, GETVAL, 0)>=g)&&(semctl(pids[1],2, GETVAL, 0)>=g))
                            {
                                time0=(rand()%5)+1;

                                printf("p0 start moving to location H (in %d seconds)\n",time0);

                                sleep(time0);
                                while(semctl(pids[1],0, GETVAL, 0)!=h)
                                {
                                    release.sem_num = p0;
                                    semop(pids[1], &release, 1);
                                }

                                printf("p0 got to location H\n");
                                sem_value = semctl(semid, 0, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",0, l[sem_value]);

                            }

                            while((semctl(pids[1],3, GETVAL, 0)!=h) && (semctl(pids[1],4, GETVAL, 0)!=h));
                            //printf("p0 G1 \n");
                            if((semctl(pids[1],3, GETVAL, 0)==h) || (semctl(pids[1],4, GETVAL, 0)==h))
                            {
                                printf("p0 start moving to location G (in %d seconds)\n",time0);

                                sleep(time0);
                                acquire.sem_num = p0;
                                semop(pids[1], &acquire, 1);
                                printf("p0 got to location G\n");
                                sem_value = semctl(semid, 0, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",0, l[sem_value]);
                            }

                            while((semctl(pids[1],1, GETVAL, 0)!=ii) || (semctl(pids[1],2, GETVAL, 0)!=ii) || (semctl(pids[1],3, GETVAL, 0)!=ii) || (semctl(pids[1],4, GETVAL, 0)!=ii) || (semctl(pids[1],5, GETVAL, 0)!=ii));
                            //printf("p0 A here\n");
                            if((semctl(pids[1],1, GETVAL, 0)==ii) && (semctl(pids[1],2, GETVAL, 0)==ii) && (semctl(pids[1],3, GETVAL, 0)==ii) && (semctl(pids[1],4, GETVAL, 0)==ii) && (semctl(pids[1],5, GETVAL, 0)==ii))
                            {
                                time0=(rand()%5)+1;
                                //printf("p0  %d == 0 \n",semctl(pids[1],0, GETVAL, 0));
                                printf("p0 start moving to location A (in %d seconds)\n",time0);

                                sleep(time0);
                                //printf("p0-2  %d == 0 \n",semctl(pids[1],0, GETVAL, 0));
                                while(semctl(pids[1],0, GETVAL, 0)!=a)
                                {
                                    acquire.sem_num = p0;
                                    semop(pids[1], &acquire, 1);
                                    //printf("p0 val = %d \n",semctl(pids[1],0, GETVAL, 0));
                                }

                                printf("p0 got to location A\n");
                                sem_value = semctl(semid, 0, GETVAL, 0);
                                //  printf("Process # %d at location : %c \n",0, l[sem_value]);
                                release.sem_num = allP;
                                semop(pids[1], &release, 1);

                            }


                        }
                    }
                    else if(i==2)
                    {
                        //printf("================= P1 ===================\n");
                        srand(getpid());
                        time01=(rand()%5)+1;
                        if((pidsP[0]+2)==getpid() )
                        {
                            if(semctl(pids[2],1, GETVAL, 0)==b)
                            {
                                printf("p1 start moving to location G (in %d seconds)\n",time01);


                                sleep(time01);
                                while(semctl(pids[2],1, GETVAL, 0)!=g)
                                {
                                    release.sem_num = p1;
                                    semop(pids[2], &release, 1);

                                }

                                printf("p1 got to location G\n");

                                sem_value = semctl(semid, 1, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);
                            }

                            // sleep(5);;
                            while((semctl(pids[1],0, GETVAL, 0)<g) ||(semctl(pids[1],1, GETVAL, 0)<g)||(semctl(pids[1],2, GETVAL, 0)<g));
                            //printf("p1 H here\n");
                            if ((semctl(pids[1],0, GETVAL, 0)>=g) &&(semctl(pids[1],1, GETVAL, 0)>=g)&&(semctl(pids[1],2, GETVAL, 0)>=g))
                            {
                                time01=(rand()%5)+1;

                                printf("p1 start moving to location H (in %d seconds)\n",time01);

                                sleep(time01);
                                //printf("P1 H1 : %d\n",semctl(pids[5],1, GETVAL, 0));
                                while(semctl(pids[2],1, GETVAL, 0)!=h)
                                {
                                    release.sem_num = p1;
                                    semop(pids[2], &release, 1);
                                    //printf("P1 H2 : %d\n",semctl(pids[5],1, GETVAL, 0));
                                }
                                printf("p1 got to location H\n");
                                sem_value = semctl(semid, 1, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);

                            }
                            //  sleep(5);;
                            while(!((semctl(pids[2],3, GETVAL, 0)==h) || (semctl(pids[2],3, GETVAL, 0)==ii)) || !((semctl(pids[2],4, GETVAL, 0)==h) || (semctl(pids[2],4, GETVAL, 0)==ii)));
                            // printf("p1 I here\n");
                            if (((semctl(pids[2],3, GETVAL, 0)==h) || (semctl(pids[2],3, GETVAL, 0)==ii)) && ((semctl(pids[2],4, GETVAL, 0)==h) || (semctl(pids[2],4, GETVAL, 0)==ii)))
                            {
                                time01=(rand()%5)+1;
                                printf("p1 start moving to location I (in %d seconds)\n",time01);

                                sleep(time01);
                                release.sem_num = p1;

                                sem_value = semctl(semid, 1, GETVAL, 0);
                                printf("p1 got to location I\n");
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);

                                semop(pids[2], &release, 1);
                            }
                            //    sleep(5);;
                            while((semctl(pids[2],0, GETVAL, 0)!=a) || !((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)));
                            //printf("p1 H1 here\n");
                            if ((semctl(pids[2],0, GETVAL, 0)==a) && ((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)))
                            {
                                time01=(rand()%5)+1;
                                printf("p1 start moving to location H (in %d seconds)\n",time01);

                                sleep(time01);
                                acquire.sem_num = p1;


                                semop(pids[2], &acquire, 1);
                                printf("p1 got to location H\n");
                                sem_value = semctl(semid, 1, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);
                            }


                            //  sleep(5);;
                            while((semctl(pids[2],3, GETVAL, 0)!=d) &&(semctl(pids[2],4, GETVAL, 0)!=e) );
                            //printf("p1 G1 here\n");
                            if((semctl(pids[2],3, GETVAL, 0)==d) ||(semctl(pids[2],4, GETVAL, 0)==e)  )
                            {

                                time01=(rand()%5)+1;
                                printf("p1 start moving to location G (in %d seconds)\n",time01);

                                sleep(time01);
                                acquire.sem_num = p1;


                                semop(pids[2], &acquire, 1);
                                printf("p1 got to location G\n");
                                sem_value = semctl(semid, 1, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);
                            }
                            sleep(2);
                            //printf("p1 %d %d \n",semctl(pids[4],3, GETVAL, 0),semctl(pids[4],4, GETVAL, 0));
                            while((semctl(pids[2],3, GETVAL, 0)!=d) ||(semctl(pids[2],4, GETVAL, 0)!=e) );
                            // printf("p1 B1 here\n");
                            if((semctl(pids[2],3, GETVAL, 0)==d) &&(semctl(pids[2],4, GETVAL, 0)==e)  )
                            {
                                time01=(rand()%5)+1;
                                printf("p1 start moving to location B (in %d seconds)\n",time01);

                                sleep(time01);
                                while(semctl(pids[2],1, GETVAL, 0)!=b)
                                {
                                    acquire.sem_num = p1;
                                    semop(pids[2], &acquire, 1);
                                    //printf("p1 : %d\n",semctl(pids[2],1, GETVAL, 0));
                                }
                                printf("p1 got to location B\n");
                                sem_value = semctl(semid, 1, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",1, l[sem_value]);
                                release.sem_num = allP;
                                semop(pids[1], &release, 1);
                            }
                        }
                    }
                    else if(i==3)
                    {
                        //printf("================= P2 ===================\n");
                        srand(getpid());
                        time02=(rand()%5)+1;
                        if((pidsP[0]+3)==getpid())
                        {
                            if(semctl(pids[3],2, GETVAL, 0)==c)
                            {
                                printf("p2 start moving to location G (in %d seconds)\n",time02);


                                sleep(time02);
                                while(semctl(pids[3],2, GETVAL, 0)!=g)
                                {
                                    release.sem_num = p2;
                                    semop(pids[3], &release, 1);

                                }

                                printf("p2 got to location G\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",2, l[sem_value]);

                            }

                            //sleep(5);;
                            while((semctl(pids[1],0, GETVAL, 0)<g) ||(semctl(pids[1],1, GETVAL, 0)<g)||(semctl(pids[1],2, GETVAL, 0)<g));
                            //printf("p2 H here\n");
                            if ((semctl(pids[1],0, GETVAL, 0)>=g) &&(semctl(pids[1],1, GETVAL, 0)>=g)&&(semctl(pids[1],2, GETVAL, 0)>=g))
                            {
                                time02=(rand()%5)+1;
                                printf("p2 start moving to location H (in %d seconds)\n",time02);

                                sleep(time01);
                                while(semctl(pids[3],2, GETVAL, 0)!=h)
                                {
                                    release.sem_num = p2;
                                    semop(pids[3], &release, 1);
                                }
                                printf("p2 got to location H\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",2, l[sem_value]);

                            }
                            sleep(5);;
                            while(!((semctl(pids[2],3, GETVAL, 0)==h) || (semctl(pids[2],3, GETVAL, 0)==ii)) || !((semctl(pids[2],4, GETVAL, 0)==h) || (semctl(pids[2],4, GETVAL, 0)==ii)));
                            //printf("p2 I here\n");
                            if (((semctl(pids[2],3, GETVAL, 0)==h) || (semctl(pids[2],3, GETVAL, 0)==ii)) && ((semctl(pids[2],4, GETVAL, 0)==h) || (semctl(pids[2],4, GETVAL, 0)==ii)))
                            {
                                time02=(rand()%5)+1;
                                printf("p2 start moving to location I (in %d seconds)\n",time02);

                                sleep(time02);
                                release.sem_num = p2;


                                semop(pids[3], &release, 1);
                                printf("p2 got to location I\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",2, l[sem_value]);
                            }
                            //    sleep(5);;
                            while((semctl(pids[2],0, GETVAL, 0)!=a) || !((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)));
                            //printf("p2 H1 here\n");
                            if ((semctl(pids[2],0, GETVAL, 0)==a) && ((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)))

                            {
                                time02=(rand()%5)+1;
                                printf("p2 start moving to location H (in %d seconds)\n",time02);

                                sleep(time02);
                                acquire.sem_num = p2;


                                semop(pids[3], &acquire, 1);
                                printf("p2 got to location H\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                ///printf("Process # %d at location : %c \n",2, l[sem_value]);
                            }

                            //    sleep(5);;
                            while((semctl(pids[3],3, GETVAL, 0)!=d) &&(semctl(pids[3],4, GETVAL, 0)!=e) );
                            //printf("p2 G1 here\n");
                            if((semctl(pids[3],3, GETVAL, 0)==d) ||(semctl(pids[3],4, GETVAL, 0)==e)  )
                            {

                                time02=(rand()%5)+1;
                                printf("p2 start moving to location G (in %d seconds)\n",time02);

                                sleep(time02);
                                acquire.sem_num = p2;


                                semop(pids[3], &acquire, 1);
                                printf("p2 got to location G\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                ///printf("Process # %d at location : %c \n",2, l[sem_value]);
                            }
                            sleep(2);;
                            //printf("p2 %d %d \n",semctl(pids[4],3, GETVAL, 0),semctl(pids[4],4, GETVAL, 0));
                            while((semctl(pids[3],3, GETVAL, 0)!=d) ||(semctl(pids[3],4, GETVAL, 0)!=e) );
                            // printf("p2 here C1\n");
                            if((semctl(pids[3],3, GETVAL, 0)==d) &&(semctl(pids[3],4, GETVAL, 0)==e)  )
                            {
                                time02=(rand()%5)+1;
                                printf("p2 start moving to location C (in %d seconds)\n",time02);
                                // printf("p21 => %d \n",semctl(pids[3],2, GETVAL, 0));
                                sleep(time02);
                                //printf("p22 => %d \n",semctl(pids[3],2, GETVAL, 0));
                                while(semctl(pids[3],2, GETVAL, 0)!=c)
                                {
                                    acquire.sem_num = p2;
                                    semop(pids[3], &acquire, 1);
                                    //printf("p2 => %d \n",semctl(pids[3],2, GETVAL, 0));
                                }
                                printf("p2 got to location C\n");
                                sem_value = semctl(semid, 2, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",2, l[sem_value]);
                                release.sem_num = allP;
                                semop(pids[1], &release, 1);
                            }

                        }


                    }
                    else if(i==4)
                    {
                        //printf("================= P3 ===================\n");
                        srand(getpid());
                        time3=(rand()%5)+1;
                        if((pidsP[0]+4)==getpid())
                        {
                            // sleep(3);;
                            // printf("//p3 %d %d %d \n",semctl(pids[4],0, GETVAL, 0),semctl(pids[4],1, GETVAL, 0),semctl(pids[4],2, GETVAL, 0));
                            while((semctl(pids[4],0, GETVAL, 0)<h) ||(semctl(pids[4],1, GETVAL, 0)<h)||(semctl(pids[4],2, GETVAL, 0)<h));
                            //printf("p3 H here\n");
                            //printf("//**p3 %d %d %d \n",semctl(pids[4],0, GETVAL, 0),semctl(pids[4],1, GETVAL, 0),semctl(pids[4],2, GETVAL, 0));
                            if ((semctl(pids[4],0, GETVAL, 0)>=h) &&(semctl(pids[4],1, GETVAL, 0)>=h)&&(semctl(pids[4],2, GETVAL, 0)>=h))
                            {
                                time3=(rand()%5)+1;
                                printf("p3 start moving to location H (in %d seconds)\n",time3);
                                sleep(time3);
                                // printf("P3 H1 : %d\n",semctl(pids[5],3, GETVAL, 0));
                                while(semctl(pids[4],3, GETVAL, 0)!=h)
                                {
                                    release.sem_num = p3;
                                    semop(pids[4], &release, 1);
                                    //  printf("P3 H2 : %d\n",semctl(pids[5],3, GETVAL, 0));
                                }
                                printf("p3 got to location H\n");
                                sem_value = semctl(semid, 3, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",3, l[sem_value]);
                            }

                            //sleep(3);;
                            //  printf("*****P3 %d %d \n",semctl(pids[4],3, GETVAL, 0),semctl(pids[4],4, GETVAL, 0));
                            while((semctl(pids[2],3, GETVAL, 0)<h) || (semctl(pids[2],4, GETVAL, 0)<h));
                            if ((semctl(pids[2],3, GETVAL, 0)>=h) && (semctl(pids[2],4, GETVAL, 0)>=h))
                            {
                                time3=(rand()%5)+1;
                                printf("p3 start moving to location I (in %d seconds)\n",time3);

                                sleep(time3);
                                release.sem_num = p3;


                                semop(pids[4], &release, 1);
                                printf("p3 got to location I\n");
                                sem_value = semctl(semid, 3, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",3, l[sem_value]);
                            }
                            sleep(5);;
                            while((semctl(pids[2],0, GETVAL, 0)!=a) || !((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)));
                            if ((semctl(pids[2],0, GETVAL, 0)==a) && ((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)))

                            {
                                time3=(rand()%5)+1;
                                printf("p3 start moving to location H (in %d seconds)\n",time3);

                                sleep(time3);
                                ///printf("P3 H1 : %d\n",semctl(pids[5],3, GETVAL, 0));
                                acquire.sem_num = p3;


                                semop(pids[4], &acquire, 1);
                                printf("p3 got to location H\n");
                                //printf("P3 H2 : %d\n",semctl(pids[5],3, GETVAL, 0));
                                sem_value = semctl(semid, 3, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",3, l[sem_value]);
                            }
                            //sleep(5);;
                            while(semctl(pids[4],5, GETVAL, 0)!=f);
                            if (semctl(pids[4],5, GETVAL, 0)==f)
                            {
                                time3=(rand()%5)+1;
                                printf("p3 start moving to location D (in %d seconds)\n",time3);

                                sleep(time3);
                                while(semctl(pids[4],3, GETVAL, 0)!=d)
                                {
                                    acquire.sem_num = p3;
                                    semop(pids[4], &acquire, 1);
                                }

                                printf("p3 got to location D\n");
                                sem_value = semctl(semid, 3, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",3, l[sem_value]);

                                release.sem_num = allP;
                                semop(pids[1], &release, 1);

                            }

                        }
                    }
                    else if(i==5)
                    {
                        //printf("================= P4 ===================\n");
                        srand(getpid());
                        time4=(rand()%5)+1;

                        if((pidsP[0]+5)==getpid())
                        {
                            //    sleep(3);
                            //printf("P4 %d %d %d \n",semctl(pids[4],0, GETVAL, 0),semctl(pids[4],1, GETVAL, 0),semctl(pids[4],2, GETVAL, 0));
                            while((semctl(pids[4],0, GETVAL, 0)<h) ||(semctl(pids[4],1, GETVAL, 0)<h)||(semctl(pids[4],2, GETVAL, 0)<h));
                            //   printf("p4 H here\n");
                            if ((semctl(pids[4],0, GETVAL, 0)>=h) &&(semctl(pids[4],1, GETVAL, 0)>=h)&&(semctl(pids[4],2, GETVAL, 0)>=h))
                            {
                                time4=(rand()%5)+1;
                                printf("p4 start moving to location H (in %d seconds)\n",time4);
                                sleep(time4);
                                //    printf("P4 H : %d\n",semctl(pids[5],4, GETVAL, 0));
                                while(semctl(pids[5],4, GETVAL, 0)!=h)
                                {
                                    release.sem_num = p4;
                                    semop(pids[5], &release, 1);
                                    //        printf("P4 H : %d\n",semctl(pids[5],4, GETVAL, 0));
                                }
                                printf("p4 got to location H\n");
                                sem_value = semctl(semid, 4, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",4, l[sem_value]);
                            }

                            //printf("****P4 %d %d \n",semctl(pids[4],3, GETVAL, 0),semctl(pids[4],4, GETVAL, 0));
                            while((semctl(pids[2],3, GETVAL, 0)<h) || (semctl(pids[2],4, GETVAL, 0)<h));
                            if ((semctl(pids[2],3, GETVAL, 0)>=h) && (semctl(pids[2],4, GETVAL, 0)>=h))
                            {
                                time4=(rand()%5)+1;
                                printf("p4 start moving to location I (in %d seconds)\n",time4);

                                sleep(time4);
                                //printf("p4 got to location I\n");
                                release.sem_num = p4;

                                semop(pids[5], &release, 1);
                                sem_value = semctl(semid, 4, GETVAL, 0);
                                ///printf("Process # %d at location : %c \n",4, l[sem_value]);
                            }
                            sleep(5);;
                            while((semctl(pids[2],0, GETVAL, 0)!=a) || !((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)));
                            if ((semctl(pids[2],0, GETVAL, 0)==a) && ((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)))

                            {
                                time4=(rand()%5)+1;
                                printf("p4 start moving to location H (in %d seconds)\n",time4);

                                sleep(time4);
                                acquire.sem_num = p4;


                                semop(pids[5], &acquire, 1);
                                //printf("P4 H1 : %d\n",semctl(pids[5],4, GETVAL, 0));
                                printf("p4 got to location H\n");
                                //printf("P4 H2 : %d\n",semctl(pids[5],4, GETVAL, 0));
                                sem_value = semctl(semid, 4, GETVAL, 0);
                                ///printf("Process # %d at location : %c \n",4, l[sem_value]);
                            }
                            //sleep(3);;
                            while(semctl(pids[5],5, GETVAL, 0)!=f);
                            if (semctl(pids[5],5, GETVAL, 0)==f)
                            {
                                time4=(rand()%5)+1;
                                printf("p4 start moving to location E (in %d seconds)\n",time4);

                                sleep(time4);
                                while(semctl(pids[5],4, GETVAL, 0)!=e)
                                {
                                    acquire.sem_num = p4;
                                    semop(pids[5], &acquire, 1);
                                }

                                printf("p4 got to location E\n");
                                sem_value = semctl(semid, 4, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",4, l[sem_value]);

                                release.sem_num = allP;
                                semop(pids[1], &release, 1);

                            }

                        }
                    }
                    else if(i==6)
                    {
                        //printf("================= P5 ===================\n");
                        srand(pid);
                        time5=rand()%5+1;
                        if((pidsP[0]+6)==getpid())
                        {

                            while((semctl(pids[4],0, GETVAL, 0)<h) ||(semctl(pids[4],1, GETVAL, 0)<h)||(semctl(pids[4],2, GETVAL, 0)<h));
                            if ((semctl(pids[4],0, GETVAL, 0)>=h) &&(semctl(pids[4],1, GETVAL, 0)>=h)&&(semctl(pids[4],2, GETVAL, 0)>=h))
                            {
                                time5=rand()%5+1;
                                printf("p5 start moving to location I (in %d seconds)\n",time5);
                                sleep(time5);
                                while(semctl(pids[6],5, GETVAL, 0)!=ii)
                                {
                                    release.sem_num = p5;
                                    semop(pids[6], &release, 1);
                                }
                                printf("p5 got to location I\n");
                                sem_value = semctl(semid, 5, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",5, l[sem_value]);

                            }
                            //    sleep(3);;
                            while((semctl(pids[2],0, GETVAL, 0)!=a) || !((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)));
                            if ((semctl(pids[2],0, GETVAL, 0)==a) && ((semctl(pids[3],1, GETVAL, 0)==ii)||(semctl(pids[3],2, GETVAL, 0)==ii) ||(semctl(pids[3],3, GETVAL, 0)==ii) ||(semctl(pids[3],4, GETVAL, 0)==ii)))

                            {
                                time5=(rand()%5)+1;
                                printf("p5 start moving to location F (in %d seconds)\n",time5);

                                sleep(time0);
                                while(semctl(pids[6],5, GETVAL, 0)!=f)
                                {
                                    acquire.sem_num = p5;
                                    semop(pids[6], &acquire, 1);
                                }
                                printf("p5 got to location F\n");
                                sem_value = semctl(semid, 5, GETVAL, 0);
                                //printf("Process # %d at location : %c \n",5, l[sem_value]);

                                release.sem_num = allP;
                                semop(pids[1], &release, 1);
                            }


                        }

                    }

                    //  sleep(5);
                }
                else
                {
                    pidsP[i] = pid;
                }

            }
            else
            {
                printf("======= Round #%d =======\n",semctl(semid,7,GETVAL,0));
                break;
            }
        }

    }
    for(int j=1; j<7; j++)
    {
        kill(pidsP[j],SIGQUIT);
    }
    if ( semctl(semid, 0, IPC_RMID, 0) == -1 )
    {
        perror("semctl -- producer");
        exit(6);
    }

    printf("Semaphore removed\n");

    /* if((pidsP[0]+1)==getpid() || (pidsP[0]+2)==getpid() ||(pidsP[0]+3)==getpid()||(pidsP[0]+4)==getpid() || (pidsP[0]+5)==getpid() ||(pidsP[0]+6)==getpid()  ){
       //printf("==============================\n");
        for ( i = 0; i < 6; i++ )
     {
         sem_value = semctl(semid, i, GETVAL, 0);
         printf("Process # %d at location : %c \n",i, l[sem_value]);

     }
       //printf("==============================\n");

      }*/







}
